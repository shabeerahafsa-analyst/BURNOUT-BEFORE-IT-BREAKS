/* Minimal SCORM 1.2 wrapper - finds the LMS API in parent/opener frames.
   Falls back to silent no-ops if no LMS is present (e.g. opened directly). */
var SCORM = (function () {
  var api = null;
  var initialized = false;

  function findAPI(win) {
    var attempts = 0;
    while (win && !win.API && win.parent && win.parent !== win && attempts < 10) {
      attempts++;
      win = win.parent;
    }
    return win ? win.API : null;
  }

  function getAPI() {
    if (api) return api;
    api = findAPI(window);
    if (!api && window.opener) api = findAPI(window.opener);
    return api;
  }

  function init() {
    var a = getAPI();
    if (a) {
      try {
        a.LMSInitialize("");
        initialized = true;
      } catch (e) { /* ignore */ }
    }
  }

  function setScore(raw, max) {
    var a = getAPI();
    if (a && initialized) {
      try {
        a.LMSSetValue("cmi.core.score.raw", String(raw));
        a.LMSSetValue("cmi.core.score.min", "0");
        a.LMSSetValue("cmi.core.score.max", String(max));
        a.LMSCommit("");
      } catch (e) { /* ignore */ }
    }
  }

  function setStatus(status) {
    // status: "completed", "incomplete", "passed", "failed"
    var a = getAPI();
    if (a && initialized) {
      try {
        a.LMSSetValue("cmi.core.lesson_status", status);
        a.LMSCommit("");
      } catch (e) { /* ignore */ }
    }
  }

  function finish() {
    var a = getAPI();
    if (a && initialized) {
      try { a.LMSFinish(""); } catch (e) { /* ignore */ }
    }
  }

  window.addEventListener("beforeunload", finish);

  return { init: init, setScore: setScore, setStatus: setStatus, finish: finish };
})();
